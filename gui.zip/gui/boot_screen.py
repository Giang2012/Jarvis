# boot_screen.py
# PART 1
from gui.effects.reactor import ReactorEffect
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *

import math
import random


class BootScreen(QWidget):

    bootFinished = Signal()

    def __init__(self):
        super().__init__()

        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet("background:#02050b;")
        self.reactor = ReactorEffect(self)
        self.progress = 0
        self.rotation = 0
        self.glow = 0
        self.scan_offset = 0
        self.grid_offset = 0
        self.cursor = True
        self.hex_rotation = 0
        self.ring_rotation = 0
        self.energy_phase = 0
        self.bloom_phase = 0

        self.full_text = "INITIALIZING JARVIS CORE..."
        self.display_text = ""

        self.logs = [
            "[ OK ] Power System",
            "[ OK ] Neural Engine",
            "[ OK ] Security Layer",
            "[ OK ] Memory Cache",
            "[ OK ] Quantum Link",
            "[ OK ] Holographic Renderer",
            "[ OK ] Voice Engine",
            "[ OK ] AI Core",
        ]

        self.current_log = 0

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.updateAnimation)
        self.timer.start(16)

        self.type_timer = QTimer(self)
        self.type_timer.timeout.connect(self.updateTyping)
        self.type_timer.start(40)

        self.log_timer = QTimer(self)
        self.log_timer.timeout.connect(self.updateLogs)
        self.log_timer.start(700)
        self.particles = []
        self.rain = []

        chars = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        for _ in range(70):

            self.rain.append({
                "x": random.randint(0, 1920),
                "y": random.randint(-1200, 0),
                "speed": random.uniform(2.5, 7.0),
                "length": random.randint(10, 26),
                "chars": "".join(
                    random.choice(chars)
                    for _ in range(60)
                )
            })

        for _ in range(160):

            self.particles.append({
                "x": random.randint(0, 1920),
                "y": random.randint(0, 1080),
                "r": random.uniform(1.0, 3.5),
                "speed": random.uniform(0.4, 2.2),
                "alpha": random.randint(40, 180)
            })

    def updateAnimation(self):

        self.rotation += 1.8
        self.hex_rotation += 0.35
        self.ring_rotation -= 0.9
        self.glow += 0.05
        self.energy_phase += 0.08
        self.bloom_phase += 0.035
        self.scan_offset += 2
        self.grid_offset += 1

        w = max(1, self.width())
        h = max(1, self.height())

        for p in self.particles:

            p["y"] -= p["speed"]

            if p["y"] < -10:

                p["y"] = h + random.randint(0, 100)
                p["x"] = random.randint(0, w)
                p["r"] = random.uniform(1.0, 3.5)
                p["speed"] = random.uniform(0.4, 2.2)
                p["alpha"] = random.randint(40, 180)

        h = max(1, self.height())
        w = max(1, self.width())

        for rain in self.rain:

            rain["y"] += rain["speed"]

            if rain["y"] > h + 300:

                rain["y"] = random.randint(-1200, -200)
                rain["x"] = random.randint(0, w)
                rain["speed"] = random.uniform(2.5, 7.0)

        if self.progress < 100:
            self.progress += 0.25
        else:
            if not hasattr(self, "_boot_done"):
                self._boot_done = True
                self.bootFinished.emit()

        self.update()

    def updateTyping(self):

        if len(self.display_text) < len(self.full_text):
            self.display_text += self.full_text[len(self.display_text)]
        else:
            self.cursor = not self.cursor

    def updateLogs(self):

        if self.current_log < len(self.logs):
            self.current_log += 1

    def paintEvent(self, event):

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        self.drawBackground(painter)
        self.drawBloom(painter)
        self.drawGlow(painter)
        self.drawBloomParticles(painter)
        self.drawGrid(painter)
        self.drawScanlines(painter)

        self.drawDigitalRain(painter)
        self.drawParticles(painter)

        self.drawOrbitRing(painter)
        self.drawHexFrame(painter)
        self.drawReactor(painter)
        self.drawEnergyBeam(painter)
        self.drawProgressRing(painter)

        self.drawLoadingText(painter)
        self.drawTerminal(painter)
    def drawDigitalRain(self, painter):

        painter.save()

        font = QFont("Consolas", 10)
        painter.setFont(font)

        for rain in self.rain:

            y = rain["y"]

            for i in range(rain["length"]):

                alpha = max(0, 220 - i * 12)

                painter.setPen(
                    QColor(
                        0,
                        255,
                        220,
                        alpha
                    )
                )

                if i < len(rain["chars"]):

                    painter.drawText(
                        int(rain["x"]),
                        int(y + i * 18),
                        rain["chars"][i]
                    )

        painter.restore()

    def drawOrbitRing(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        painter.translate(cx, cy)
        painter.rotate(self.ring_rotation)

        pen = QPen(QColor(0, 220, 255, 90))
        pen.setWidth(2)

        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)

        r = 132

        for i in range(12):

            painter.drawArc(
                QRectF(
                    -r,
                    -r,
                    r * 2,
                    r * 2
                ),
                i * 30 * 16,
                12 * 16
            )

        painter.restore()

    def drawHexFrame(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        painter.translate(cx, cy)
        painter.rotate(self.hex_rotation)

        pen = QPen(QColor(0, 255, 255, 130))
        pen.setWidth(2)

        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)

        radius = 88

        points = []

        for i in range(6):

            angle = math.radians(i * 60 - 30)

            points.append(
                QPointF(
                    radius * math.cos(angle),
                    radius * math.sin(angle)
                )
            )

        painter.drawPolygon(QPolygonF(points))

        radius = 68

        points.clear()

        for i in range(6):

            angle = math.radians(i * 60 + 30)

            points.append(
                QPointF(
                    radius * math.cos(angle),
                    radius * math.sin(angle)
                )
            )

        painter.drawPolygon(QPolygonF(points))

        painter.restore()

    def drawEnergyBeam(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        length = 150

        alpha = int(
            90 + 60 * abs(math.sin(self.energy_phase))
        )

        beam = QLinearGradient(
            cx,
            cy - length,
            cx,
            cy + length
        )

        beam.setColorAt(
            0,
            QColor(0, 255, 255, 0)
        )

        beam.setColorAt(
            0.5,
            QColor(120, 255, 255, alpha)
        )

        beam.setColorAt(
            1,
            QColor(0, 255, 255, 0)
        )

        painter.setPen(Qt.NoPen)
        painter.setBrush(beam)

        painter.drawRoundedRect(
            QRectF(
                cx - 3,
                cy - length,
                6,
                length * 2
            ),
            3,
            3
        )

        beam2 = QLinearGradient(
            cx,
            cy - 90,
            cx,
            cy + 90
        )

        beam2.setColorAt(
            0,
            QColor(255, 255, 255, 0)
        )

        beam2.setColorAt(
            0.5,
            QColor(255, 255, 255, 120)
        )

        beam2.setColorAt(
            1,
            QColor(255, 255, 255, 0)
        )

        painter.setBrush(beam2)

        painter.drawRoundedRect(
            QRectF(
                cx - 1,
                cy - 90,
                2,
                180
            ),
            1,
            1
        )

        painter.restore()

    def drawBackground(self, painter):

        painter.fillRect(self.rect(), QColor(2, 6, 12))

        gradient = QRadialGradient(
            self.width() / 2,
            self.height() / 2,
            self.width() * 0.8
        )

        gradient.setColorAt(0.0, QColor(0, 255, 255, 22))
        gradient.setColorAt(0.4, QColor(0, 180, 255, 12))
        gradient.setColorAt(1.0, QColor(0, 0, 0, 0))

        painter.fillRect(self.rect(), gradient)

    def drawGrid(self, painter):

        painter.save()

        pen = QPen(QColor(0, 180, 255, 18))
        pen.setWidth(1)
        painter.setPen(pen)

        step = 40

        ox = self.grid_offset % step
        oy = self.grid_offset % step

        for x in range(-step, self.width() + step, step):
            painter.drawLine(
                x + ox,
                0,
                x + ox,
                self.height()
            )

        for y in range(-step, self.height() + step, step):
            painter.drawLine(
                0,
                y + oy,
                self.width(),
                y + oy
            )

        painter.restore()

    def drawScanlines(self, painter):

        painter.save()

        pen = QPen(QColor(0, 255, 255, 10))
        painter.setPen(pen)

        for y in range(0, self.height(), 4):
            painter.drawLine(0, y, self.width(), y)

        glow = QLinearGradient(
            0,
            self.scan_offset,
            0,
            self.scan_offset + 120
        )

        glow.setColorAt(0, QColor(0, 255, 255, 0))
        glow.setColorAt(0.5, QColor(0, 255, 255, 45))
        glow.setColorAt(1, QColor(0, 255, 255, 0))

        painter.fillRect(
            0,
            self.scan_offset - 60,
            self.width(),
            120,
            glow
        )

        if self.scan_offset > self.height() + 120:
            self.scan_offset = -120

        painter.restore()

    def drawReactor(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        painter.translate(cx, cy)

        t = self.glow

        self.drawOuterGlow(painter)
        self.drawTriangles(painter)
        self.drawOuterTicks(painter)
        self.drawReactorRings(painter)
        self.drawEnergyNodes(painter)
        self.drawEnergyLinks(painter)
        self.drawEnergyOrbits(painter)
        self.drawReactorCore(painter)
        self.drawReactorFlash(painter)

        painter.restore()

    def drawGlow(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        painter.setRenderHint(
            QPainter.Antialiasing
        )

        pulse = (
            math.sin(
                self.glow * 3
            ) + 1
        ) / 2

        for i in range(10):

            radius = 45 + i * 7 + pulse * 4

            alpha = max(
                0,
                80 - i * 8
            )

            pen = QPen(
                QColor(
                    120,
                    255,
                    255,
                    alpha
                )
            )

            pen.setWidth(2)

            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)

            painter.drawEllipse(
                QPointF(cx, cy),
                radius,
                radius
            )

        flare = QRadialGradient(
            QPointF(cx, cy),
            70
        )

        flare.setColorAt(
            0,
            QColor(
                255,
                255,
                255,
                60
            )
        )

        flare.setColorAt(
            0.35,
            QColor(
                120,
                255,
                255,
                45
            )
        )

        flare.setColorAt(
            1,
            QColor(
                0,
                255,
                255,
                0
            )
        )

        painter.setPen(Qt.NoPen)
        painter.setBrush(flare)

        painter.drawEllipse(
            QPointF(cx, cy),
            70,
            70
        )

        # ===== ROTATING HALO =====

        painter.save()

        painter.translate(cx, cy)
        painter.rotate(self.rotation * 1.5)

        pen = QPen(QColor(180, 255, 255, 120))
        pen.setWidth(2)

        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)

        for i in range(8):

            painter.drawArc(
                QRectF(
                    -82,
                    -82,
                    164,
                    164
                ),
                i * 45 * 16,
                18 * 16
            )

        painter.restore()

        # ===== LIGHT RAYS =====

        painter.save()

        painter.translate(cx, cy)
        painter.rotate(-self.rotation * 2)

        pen = QPen(QColor(255, 255, 255, 45))
        pen.setWidth(1)

        painter.setPen(pen)

        for i in range(16):

            painter.rotate(22.5)

            painter.drawLine(
                72,
                0,
                105,
                0
            )

        painter.restore()

    def drawBloomParticles(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        painter.translate(cx, cy)

        for i in range(28):

            angle = math.radians(
                i * (360 / 28) +
                self.rotation * 1.8
            )

        radius = (
            92
            + math.sin(
                self.bloom_phase * 3 + i * 0.45
            ) * 14
            + abs(
                math.sin(
                    self.glow * 2
                )
            ) * 10
        )
        x = math.cos(angle) * radius
        y = math.sin(angle) * radius

        g = QRadialGradient(
            QPointF(x, y),
            8
        )

        g.setColorAt(
            0,
            QColor(255, 255, 255, 180)
        )

        g.setColorAt(
            0.35,
            QColor(120, 255, 255, 130)
        )

        g.setColorAt(
            1,
            QColor(0, 255, 255, 0)
        )

        painter.setBrush(g)
        painter.setPen(Qt.NoPen)

        painter.drawEllipse(
            QPointF(x, y),
            5,
            5
        )

        painter.restore()
        
    def drawProgressRing(self, painter):

        painter.save()

        cx = self.width() / 2
        cy = self.height() / 2 - 40

        r = 145

        painter.setPen(
            QPen(
                QColor(0, 255, 255, 25),
                6
            )
        )

        painter.setBrush(Qt.NoBrush)

        painter.drawEllipse(
            QPointF(cx, cy),
            r,
            r
        )

        pen = QPen(
            QColor(0, 255, 255),
            6
        )

        pen.setCapStyle(Qt.RoundCap)

        painter.setPen(pen)

        angle = int(
            self.progress / 100 * 360 * 16
        )

        painter.drawArc(
            QRectF(
                cx - r,
                cy - r,
                r * 2,
                r * 2
            ),
            90 * 16,
            -angle
        )

        painter.restore()

    def drawLoadingText(self, painter):

        painter.save()

        cx = self.width() / 2

        title_font = QFont(
            "Consolas",
            16,
            QFont.Bold
        )

        painter.setFont(title_font)

        painter.setPen(
            QColor(120, 255, 255)
        )

        painter.drawText(
            QRectF(
                0,
                self.height() / 2 + 150,
                self.width(),
                40
            ),
            Qt.AlignCenter,
            self.display_text +
            ("|" if self.cursor else "")
        )

        percent_font = QFont(
            "Consolas",
            28,
            QFont.Bold
        )

        painter.setFont(percent_font)

        painter.drawText(
            QRectF(
                0,
                self.height() / 2 + 185,
                self.width(),
                60
            ),
            Qt.AlignCenter,
            f"{int(self.progress)}%"
        )

        painter.restore()

    def drawTerminal(self, painter):

        painter.save()

        font = QFont(
            "Consolas",
            10
        )

        painter.setFont(font)

        x = 60
        y = self.height() - 180

        for i in range(self.current_log):

            painter.setPen(
                QColor(
                    120,
                    255,
                    180
                )
            )

            painter.drawText(
                x,
                y + i * 22,
                self.logs[i]
            )

        painter.restore()

    def drawParticles(self, painter):

        painter.save()

        painter.setPen(Qt.NoPen)

        for p in self.particles:

            glow = QRadialGradient(
                QPointF(
                    p["x"],
                    p["y"]
                ),
                p["r"] * 4
            )

            glow.setColorAt(
                0,
                QColor(
                    180,
                    255,
                    255,
                    p["alpha"]
                )
            )

            glow.setColorAt(
                0.45,
                QColor(
                    0,
                    255,
                    255,
                    p["alpha"] // 2
                )
            )

            glow.setColorAt(
                1,
                QColor(
                    0,
                    255,
                    255,
                    0
                )
            )

            painter.setBrush(glow)

            painter.drawEllipse(
                QPointF(
                    p["x"],
                    p["y"]
                ),
                p["r"] * 4,
                p["r"] * 4
            )

            painter.setBrush(
                QColor(
                    220,
                    255,
                    255,
                    p["alpha"]
                )
            )

            painter.drawEllipse(
                QPointF(
                    p["x"],
                    p["y"]
                ),
                p["r"],
                p["r"]
            )

        painter.restore()
    