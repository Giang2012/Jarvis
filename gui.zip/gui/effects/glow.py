from PySide6.QtGui import QColor, QPen


class Glow:

    @staticmethod
    def pen(width=2, alpha=255):

        return QPen(
            QColor(
                0,
                255,
                255,
                alpha
            ),
            width
        )