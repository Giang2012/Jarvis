from PySide6.QtGui import *
from PySide6.QtCore import *
import math


class ReactorEffect:

    def __init__(self, boot):
        self.boot = boot

    def draw(self, painter):

        self.drawOuterGlow(painter)
        self.drawTriangles(painter)
        self.drawOuterTicks(painter)
        self.drawRings(painter)
        self.drawNodes(painter)
        self.drawLinks(painter)
        self.drawOrbits(painter)
        self.drawCore(painter)
        self.drawFlash(painter)

    def drawOuterGlow(self, painter):
        pass

    def drawTriangles(self, painter):
        pass

    def drawOuterTicks(self, painter):
        pass

    def drawRings(self, painter):
        pass

    def drawNodes(self, painter):
        pass

    def drawLinks(self, painter):
        pass

    def drawOrbits(self, painter):
        pass

    def drawCore(self, painter):
        pass

    def drawFlash(self, painter):
        pass